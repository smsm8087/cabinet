#include "stdafx.h"
#include "cNode.h"


cNode::cNode()
{
}


cNode::~cNode()
{
}
