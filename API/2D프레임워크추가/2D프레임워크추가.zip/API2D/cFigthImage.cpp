#include "stdafx.h"
#include "cFigthImage.h"


cFigthImage::cFigthImage()
{
}


cFigthImage::~cFigthImage()
{
}
