#pragma once
class cMapImage
{
public:
	cMapImage();
	~cMapImage();
};

