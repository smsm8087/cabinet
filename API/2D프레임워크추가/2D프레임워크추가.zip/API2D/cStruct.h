#pragma once

//
//struct RectInfo
//{
//	float F;
//	float G;
//	float H;
//	eState RectState;
//	eStartEnd StartEnd;
//	POINT RectPt;
//	int Row;
//	int Col;
//	int Index;
//	RectInfo() {}
//	RectInfo(float _f, float _g, float _h, eState _eState, eStartEnd _StartEnd, POINT _RectPt, int _row, int _col, int _Index)
//	{
//		F = _f;
//		G = _g;
//		H = _h;
//		RectState = _eState;
//		StartEnd = _StartEnd;
//		RectPt = _RectPt;
//		Row = _row;
//		Col = _col;
//		Index = _Index;
//	};
//};

//���� ����ü
struct stWorker
{
	int speed;
	int HP;
};

struct stBuilding
{

};