#include "stdafx.h"
#include "cMapImage.h"


cMapImage::cMapImage()
{
}


cMapImage::~cMapImage()
{
}
