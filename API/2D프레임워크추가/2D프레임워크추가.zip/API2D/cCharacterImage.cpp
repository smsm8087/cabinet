#include "stdafx.h"
#include "cCharacterImage.h"


cCharacterImage::cCharacterImage()
{
}


cCharacterImage::~cCharacterImage()
{
}
