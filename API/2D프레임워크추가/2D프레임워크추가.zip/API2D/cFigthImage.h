#pragma once
class cFigthImage
{
public:
	cFigthImage();
	~cFigthImage();
};

