#pragma once
class cCharacterImage
{
public:
	cCharacterImage();
	~cCharacterImage();
};

