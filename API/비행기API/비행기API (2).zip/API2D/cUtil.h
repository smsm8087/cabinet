#pragma once
static class cUtil
{
public:
	static void DrawEllipse(HDC hdc, float fRadius, cVector2 vCenter);
};

