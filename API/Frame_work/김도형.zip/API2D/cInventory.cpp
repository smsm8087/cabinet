#include "stdafx.h"
#include "cInventory.h"


cInventory::cInventory()
{
}


cInventory::~cInventory()
{
}
