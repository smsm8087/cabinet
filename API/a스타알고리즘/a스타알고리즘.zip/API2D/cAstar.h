#pragma once
class cAstar
{
public:
	cAstar();
	~cAstar();
};

