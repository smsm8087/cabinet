#include "stdafx.h"
#include "cAstar.h"


cAstar::cAstar()
{
}


cAstar::~cAstar()
{
}
