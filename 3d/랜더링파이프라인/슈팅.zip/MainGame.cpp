#include "stdafx.h"
#include "MainGame.h"


MainGame::MainGame()
{
	player = new Player;	
	for (int i = 0; i < 10; i++)
	{
		Enemy* enemy = new Enemy;
		vecEnemy.push_back(enemy);
	}

}


MainGame::~MainGame()
{
	delete player;
	for (auto p : vecEnemy)
	{
		if (p)
		{
			delete p;
			p = nullptr;
		}
	}
}

void MainGame::Update()
{
	player->Update();
	for (auto p : vecEnemy)
	{
		float angle = atan2((p->GetWorldPos().y-35) - player->GetWorldPos().y, (p->GetWorldPos().x-35) - player->GetWorldPos().x);
		p->SetAngle(angle);
		p->Update();
	}
	if (KEYBOARD->KeyDown(VK_LBUTTON))
	{
		Bullet* bullet = new Bullet;
		bullet->Fire(player->GetWorldPos().x, player->GetWorldPos().y, player->GetAngle());
		vecBullet.push_back(bullet);
	}
	for (auto p : vecBullet)
	{
		p->Update();
		RECT rcTemp;
		for (auto j : vecEnemy)
		{
			if (IntersectRect(&rcTemp, &p->GetBulletRc(), &j->GetRect()))
			{
				p->SetActive(false);
				j->SetActive(false);
			}
		}
	}
}

void MainGame::Render()
{
	player->Render();
	for (auto p : vecEnemy)
	{
		p->Render();
	}
	for (auto p : vecBullet)
	{
		p->Render();
	}
}
